import React from "react";
import { Link } from "react-router-dom";
import "../styles/Navbar.css";


  // Check if the user is an admin
  // const isAdmin = localStorage.getItem("role") === "admin";
  const Navbar = () => {
    const Role = localStorage.getItem("role"); // Fetch role from localStorage
  
    return (
      <nav className="navbar">
        <h1>Blood Donation</h1>
        <ul>
          <li><Link to="/home">Home</Link></li>
          {/* Conditionally render links based on role */}
          {Role === "Admin" ? (
            <>
              <li><Link to="/donor-list">Donor List</Link></li>
              {/* <li><Link to="/manage-users">Manage Users</Link></li> */}
            </>
          ) : (
            <li><Link to="/register">Become a Donor</Link></li>
          )}
          <li><Link to="/blood-banks">Blood Banks</Link></li>
          <li><Link to="/events">Events</Link></li>
          <li><Link to="/">Logout</Link></li>
        </ul>
      </nav>
    );
  };

  

export default Navbar;
