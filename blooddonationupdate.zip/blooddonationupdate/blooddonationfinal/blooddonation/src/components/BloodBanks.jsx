import React, { useState, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import Navbar from "./Navbar";
import axios from "axios";

const BloodBanks = () => {
  const [bloodBanks, setBloodBanks] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [newBloodBank, setNewBloodBank] = useState({
    name: "",
    location: "",
    contact: "",
  });

  useEffect(() => {
    const userRole = localStorage.getItem("role");
    setIsAdmin(userRole === "Admin");

    fetchBloodBanks();
  }, []);

  const fetchBloodBanks = async () => {
    try {
      const response = await axios.get(
        "http://localhost/blooddonation/controllers/api/admin/get/bloodbankget.php"
      );
      setBloodBanks(response.data);
    } catch (error) {
      console.error("Error fetching blood banks:", error);
    }
  };

  const handleOpenDialog = () => setOpenDialog(true);
  const handleCloseDialog = () => setOpenDialog(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewBloodBank((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    try {
      const requestData = {
        bloodbank: newBloodBank.name,
        Location: newBloodBank.location,
        Contact: newBloodBank.contact,
      };

      const response = await axios.post(
        "http://localhost/blooddonation/controllers/api/admin/post/bloodbankpost.php",
        requestData,
        { headers: { "Content-Type": "application/json" } }
      );

      setBloodBanks([...bloodBanks, response.data]); // Add the new blood bank to the state
      setNewBloodBank({ name: "", location: "", contact: "" }); // Reset form
      handleCloseDialog();
    } catch (error) {
      console.error("Error adding blood bank:", error);
    }
  };

  return (
    <>
      <Navbar />

      {isAdmin && (
        <Button
          variant="contained"
          color="primary"
          sx={{ margin: 2 }}
          onClick={handleOpenDialog}
          style={{ width: "97vw" }}
        >
          Add Blood Bank
        </Button>
      )}

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Location</TableCell>
              <TableCell>Contact</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {bloodBanks.map((bank) => (
              <TableRow key={bank.id}>
                <TableCell>{bank.name}</TableCell>
                <TableCell>{bank.location}</TableCell>
                <TableCell>{bank.contact}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={openDialog} onClose={handleCloseDialog}>
        <DialogTitle>Create New Blood Bank</DialogTitle>
        <DialogContent>
          <TextField
            label="Blood Bank Name"
            name="name"
            value={newBloodBank.name}
            onChange={handleInputChange}
            fullWidth
            margin="normal"
          />
          <TextField
            label="Location"
            name="location"
            value={newBloodBank.location}
            onChange={handleInputChange}
            fullWidth
            margin="normal"
          />
          <TextField
            label="Contact"
            name="contact"
            value={newBloodBank.contact}
            onChange={handleInputChange}
            fullWidth
            margin="normal"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} color="primary">
            Cancel
          </Button>
          <Button onClick={handleSubmit} color="primary">
            Add Blood Bank
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default BloodBanks;
