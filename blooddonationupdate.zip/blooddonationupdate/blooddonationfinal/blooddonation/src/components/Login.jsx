import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { TextField, Button, Typography, Box, Paper, Alert } from "@mui/material";
import { styled } from "@mui/material/styles";
import axios from "axios";
import bg from "../images/blood.jpg";

const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(4),
  maxWidth: 400,
  marginTop: theme.spacing(8),
  boxShadow: theme.shadows[5],
  borderRadius: theme.shape.borderRadius,
  backgroundColor: "rgba(255, 255, 255, 0.8)",
}));

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post(
        "http://localhost/blooddonation/controllers/api/admin/get/get.php",
        { Email: email, Password: password }
      );

      console.log("API Response:", response.data);

      if (response.data.success) {
        const { Role } = response.data;

        // Save authentication and role to localStorage
        localStorage.setItem("auth", "true");
        localStorage.setItem("role", Role);

        // Navigate based on role
        if (Role === "Admin") {
          localStorage.setItem('currentUser',{email,password,Role})
          navigate("/home"); 
        
        } else if (Role === "User") {
          localStorage.setItem('currentUser',{email,password,Role})
          navigate("/home"); // Redirect to User Dashboard
        }
      } else {
        setError(response.data.message);
      }
    } catch (error) {
      console.error("Login failed:", error);
      setError("An error occurred. Please try again.");
    }
  };

  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "97vh",
        backgroundImage: `url(${bg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <StyledPaper>
        <Typography variant="h4" align="center" gutterBottom color="primary">
          Login
        </Typography>
        {error && <Alert severity="error" sx={{ marginBottom: 2 }}>{error}</Alert>}
        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Email"
            variant="outlined"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Password"
            type="password"
            variant="outlined"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            margin="normal"
            required
          />
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="secondary"
            sx={{ marginTop: 2, padding: 1 }}
          >
            Login
          </Button>
        </form>
        <Typography variant="body2" align="center" sx={{ marginTop: 2 }}>
          New user? <Link to="/signup">Create an account</Link>
        </Typography>
      </StyledPaper>
    </Box>
  );
};

export default Login;
