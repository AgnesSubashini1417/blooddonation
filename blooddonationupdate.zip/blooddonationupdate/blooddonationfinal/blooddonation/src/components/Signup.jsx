import React, { useState } from "react";
import { TextField, Button, Typography, Box, Paper, MenuItem } from "@mui/material";
import { styled } from "@mui/material/styles";
import { Link } from "react-router-dom";
import axios from "axios";
import bg from "../images/blood.jpg";

const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(4),
  maxWidth: 400,
  marginTop: theme.spacing(8),
  boxShadow: theme.shadows[5],
  borderRadius: theme.shape.borderRadius,
  backgroundColor: "rgba(255, 255, 255, 0.8)",
}));

const Signup = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    role: "user", // Default role is set to 'user'
  });

  const [error, setError] = useState(null);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    try {
      const response = await axios.post(
        "http://localhost/blooddonation/controllers/api/admin/post/post.php",
        {
          Fullname: formData.name,
          Email: formData.email,
          Password: formData.password,
          Role: formData.role, // Send role in the payload
        }
      );
  
      const message = response.data.message || response.data; // Adjust based on your server response
      alert(message);
      setFormData({ name: "", email: "", password: "", role: "user" }); // Clear form
      setError(null); // Clear any previous errors
    } catch (err) {
      setError(err.response?.data?.error || "Signup failed. Please try again.");
    }
  };

  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "97vh",
        backgroundImage: `url(${bg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <StyledPaper>
        <Typography variant="h4" align="center" gutterBottom color="primary">
          Signup
        </Typography>
        {error && (
          <Typography color="error" align="center" gutterBottom>
            {error}
          </Typography>
        )}
        <form onSubmit={handleSubmit}>
          <TextField
            fullWidth
            label="Full Name"
            name="name"
            variant="outlined"
            value={formData.name}
            onChange={handleChange}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Email"
            name="email"
            type="email"
            variant="outlined"
            value={formData.email}
            onChange={handleChange}
            margin="normal"
            required
          />
          <TextField
            fullWidth
            label="Password"
            name="password"
            type="password"
            variant="outlined"
            value={formData.password}
            onChange={handleChange}
            margin="normal"
            required
          />
          {/* <TextField
            fullWidth
            select
            label="Role"
            name="role"
            variant="outlined"
            value={formData.role}
            onChange={handleChange}
            margin="normal"
            required */}
          {/* > */}
          
          <Button
            type="submit"
            fullWidth
            variant="contained"
            color="secondary"
            sx={{ marginTop: 2, padding: 1 }}
          >
            Signup
          </Button>
        </form>
        <Typography variant="body2" align="center" sx={{ marginTop: 2 }}>
          Already have an account? <Link to="/">Login here</Link>
        </Typography>
      </StyledPaper>
    </Box>
  );
};

export default Signup;
