import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  CircularProgress,
} from "@mui/material";
import { Delete as DeleteIcon } from "@mui/icons-material";

const DonorList = () => {
  const [donors, setDonors] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch donor data from the backend
  useEffect(() => {
    axios
      .get("http://localhost/blooddonation/controllers/api/admin/get/Donorget.php")
      .then((response) => {
        setDonors(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching donors:", error);
        setLoading(false);
      });
  }, []);

  // Handle delete action
  const handleDelete = (name) => {
    axios
      .post("http://localhost/blooddonation/controllers/api/admin/delete/delete.php", { name })
      .then((response) => {
        console.log(response.data.message);
        setDonors(donors.filter((donor) => donor.Fullname !== name));
      })
      .catch((error) => {
        console.error("Error deleting donor:", error);
      });
  };

  if (loading) {
    return <CircularProgress />;
  }

  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell>Email</TableCell>
            <TableCell>Blood Type</TableCell>
            <TableCell>Location</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {donors.length > 0 ? (
            donors.map((donor) => (
              <TableRow key={donor.id}>
                <TableCell>{donor.Fullname}</TableCell>
                <TableCell>{donor.Email}</TableCell>
                <TableCell>{donor.Bloodtype}</TableCell>
                <TableCell>{donor.Location}</TableCell>
                <TableCell>
                  <IconButton color="error" onClick={() => handleDelete(donor.Fullname)}>
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={5} align="center">
                No donors found.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default DonorList;
