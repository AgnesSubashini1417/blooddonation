import React, { useState, useEffect } from "react";
import axios from "axios"; // Import Axios
import "../styles/DonorRegistration.css";
import Navbar from "./Navbar";
import DonorList from "./DonorList";

const DonorRegistration = () => {
  const [showForm, setShowForm] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false); // Tracks if logged-in user is admin
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    bloodType: "",
    location: "",
  });

  // Simulate user role based on login (fetch from backend in real case)
  useEffect(() => {
    const userRole = localStorage.getItem("role"); // Store role after login
    // console.log(userRole);
    if (userRole === "Admin") {
      setIsAdmin(true);
    }
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost/blooddonation/controllers/api/admin/post/Donorregister.php", // Backend URL
        {
          Fullname: formData.name,
          Email: formData.email,
          Bloodtype: formData.bloodType,
          Location: formData.location,
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      if (response.data.message) {
        alert(response.data.message); // Show success message from backend
      } else {
        alert("Registration Successful!");
      }
      setFormData({
        name: "",
        email: "",
        bloodType: "",
        location: "",
      }); // Clear the form
    } catch (error) {
      console.error("Error during registration:", error);
      alert("An error occurred while registering. Please try again.");
    }
  };

  const toggleForm = () => {
    setShowForm(!showForm);
  };

  return (
    <>
      <Navbar />
      <div className="donor-registration">
        {isAdmin ? (
          <DonorList /> // Show DonorList if logged-in user is admin
        ) : !showForm ? (
          <div className="info-section">
            <h2>Why Donate Blood?</h2>
            <ul>
              <li>Blood donation saves lives and helps those in critical need.</li>
              <li>It improves cardiovascular health and reduces harmful iron levels.</li>
              <li>Donors gain a sense of pride and purpose by contributing to society.</li>
            </ul>
            <button className="donor-button" onClick={toggleForm}>
              Become a Donor
            </button>
          </div>
        ) : (
          <div className="form-section">
            <h2>Donor Registration</h2>
            <form onSubmit={handleSubmit}>
              <input
                type="text"
                name="name"
                placeholder="Full Name"
                value={formData.name}
                onChange={handleChange}
                required
              />
              <input
                type="email"
                name="email"
                placeholder="Email"
                value={formData.email}
                onChange={handleChange}
                required
              />
              <select
                name="bloodType"
                value={formData.bloodType}
                onChange={handleChange}
                required
              >
                <option value="">Select Blood Type</option>
                <option value="A+">A+</option>
                <option value="O+">O+</option>
                <option value="B+">B+</option>
                <option value="AB+">AB+</option>
              </select>
              <input
                type="text"
                name="location"
                placeholder="Location"
                value={formData.location}
                onChange={handleChange}
                required
              />
              <button type="submit">Register</button>
            </form>
          </div>
        )}
      </div>
    </>
  );
};

export default DonorRegistration;
