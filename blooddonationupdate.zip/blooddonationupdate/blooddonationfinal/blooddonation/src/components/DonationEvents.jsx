import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  Card,
  CardContent,
  Typography,
  Grid,
  Box,
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import Navbar from "./Navbar";
import bg from "../images/blood.jpg";

const StyledCard = styled(Card)(({ theme }) => ({
  width: "100%",
  height: "100%",
  maxWidth: 345,
  margin: theme.spacing(2),
  boxShadow: theme.shadows[8],
  borderRadius: theme.shape.borderRadius,
  backgroundColor: "rgba(255, 255, 255, 0.9)",
  backdropFilter: "blur(10px)",
  transition: "transform 0.3s ease, box-shadow 0.3s ease",
  display: "flex",
  flexDirection: "column",
  justifyContent: "space-between",
  "&:hover": {
    transform: "scale(1.05)",
    boxShadow: theme.shadows[12],
  },
}));

const DonationEvents = () => {
  const [events, setEvents] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [newEvent, setNewEvent] = useState({ title: "", date: "", location: "" });
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const response = await axios.get("http://localhost/blooddonation/controllers/api/admin/get/Eventget.php");
        if (response.data.events) {
          setEvents(response.data.events);
        } else {
          setEvents([]);
        }
      } catch (error) {
        console.error("Error fetching events:", error);
        alert("Failed to fetch events. Please try again later.");
      }
    };

    const userRole = localStorage.getItem("role");
    if (userRole === "Admin") {
      setIsAdmin(true);
    }

    fetchEvents();
  }, []);

  const handleOpenDialog = () => {
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewEvent((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    try {
      const response = await axios.post("http://localhost/blooddonation/controllers/api/admin/post/Eventspost.php", {
        eventtitle: newEvent.title,
        eventdate: newEvent.date,
        Location: newEvent.location,
      });

      if (response.data.message) {
        alert(response.data.message);
        setEvents((prevEvents) => [
          ...prevEvents,
          {
            id: response.data.id,
            eventtitle: newEvent.title,
            eventdate: newEvent.date,
            Location: newEvent.location,
          },
        ]);
        setNewEvent({ title: "", date: "", location: "" });
        handleCloseDialog();
      }
    } catch (error) {
      console.error("Error creating event:", error);
      alert("Failed to create event. Please try again.");
    }
  };

  const handleDelete = async (eventId) => {
    try {
      const response = await axios.delete(
        `http://localhost/blooddonation/controllers/api/admin/delete/deleteevent.php?id=${eventId}`
      );
      if (response.data.message) {
        alert(response.data.message);
        setEvents(events.filter((event) => event.id !== eventId));
      }
    } catch (error) {
      console.error("Error deleting event:", error);
      alert("Failed to delete event. Please try again.");
    }
  };

  return (
    <>
      <Navbar />
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          minHeight: "72vh",
          backgroundImage: `url(${bg})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          padding: 4,
        }}
      >
        <Typography
          variant="h3"
          gutterBottom
          sx={{
            color: "#fff",
            textShadow: "2px 2px 4px rgba(0, 0, 0, 0.7)",
            marginBottom: 4,
          }}
        >
          Donation Events
        </Typography>

        {isAdmin && (
          <Button
            variant="contained"
            color="primary"
            sx={{ marginBottom: 3 }}
            onClick={handleOpenDialog}
          >
            Add Event
          </Button>
        )}

        <Grid container spacing={3} justifyContent="center" alignItems="stretch">
          {events.map((event) => (
            <Grid item key={event.id} xs={12} sm={6} md={4}>
              <StyledCard>
                <CardContent>
                  <Typography variant="h5" gutterBottom sx={{ color: "#1a237e", fontWeight: "bold" }}>
                    {event.eventtitle}
                  </Typography>
                  <Typography variant="body1" sx={{ color: "#424242" }}>
                    <strong>Date:</strong> {event.eventdate}
                  </Typography>
                  <Typography variant="body1" sx={{ color: "#424242" }}>
                    <strong>Location:</strong> {event.Location}
                  </Typography>
                </CardContent>
                {isAdmin && (
                  <Box sx={{ padding: 2 }}>
                    <Button
                      variant="outlined"
                      color="error"
                      fullWidth
                      onClick={() => handleDelete(event.id)}
                    >
                      Delete
                    </Button>
                  </Box>
                )}
              </StyledCard>
            </Grid>
          ))}
        </Grid>
      </Box>

      <Dialog open={openDialog} onClose={handleCloseDialog}>
        <DialogTitle>Create New Event</DialogTitle>
        <DialogContent>
          <TextField
            label="Event Title"
            name="title"
            value={newEvent.title}
            onChange={handleInputChange}
            fullWidth
            margin="normal"
          />
          <TextField
            label="Event Date"
            name="date"
            type="date"
            value={newEvent.date}
            onChange={handleInputChange}
            fullWidth
            margin="normal"
            InputLabelProps={{
              shrink: true,
            }}
          />
          <TextField
            label="Event Location"
            name="location"
            value={newEvent.location}
            onChange={handleInputChange}
            fullWidth
            margin="normal"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} color="primary">
            Cancel
          </Button>
          <Button onClick={handleSubmit} color="primary">
            Add Event
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default DonationEvents;
