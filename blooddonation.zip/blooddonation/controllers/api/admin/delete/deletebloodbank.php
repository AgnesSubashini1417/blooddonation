<?php
// Enable CORS for local development
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    header('HTTP/1.1 200 OK');
    exit();
}

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$dbname = "blooddonation";

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Get the ID from the request
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Ensure the ID is an integer
    error_log("ID received for deletion: $id");

    // SQL query to delete the specific row
    $query = "DELETE FROM bloodbank WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);

    if ($stmt->execute() && $stmt->affected_rows > 0) {
        echo json_encode(["message" => "Bloodbank deleted successfully."]);
    } else {
        http_response_code(400);
        echo json_encode(["error" => "Failed to delete bloodbank."]);
    }

    $stmt->close();
} else {
    http_response_code(400);
    echo json_encode(["error" => "Invalid request - ID is missing."]);
}

$conn->close();
?>
