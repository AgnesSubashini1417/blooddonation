<?php
// Enable CORS for local development
header("Access-Control-Allow-Origin: http://localhost:5173"); // Allow your frontend to access
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    header('HTTP/1.1 200 OK');
    exit();
}

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$dbname = "blooddonation";

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Get the donor name from the request body
$data = json_decode(file_get_contents("php://input"), true);

// Log incoming data for debugging
error_log("Received data: " . print_r($data, true));

if (isset($data['name'])) {
    $name = $data['name'];
    error_log("Name received: $name"); // Log the name for debugging

    // Delete the donor with the specified name
    $query = "DELETE FROM donorregister WHERE Fullname = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $name);

    if ($stmt->execute()) {
        echo json_encode(["message" => "Donor deleted successfully"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Failed to delete donor"]);
    }

    $stmt->close();
} else {
    http_response_code(400);
    echo json_encode(["error" => "Invalid request - Name is missing"]);
}

$conn->close();
?>
