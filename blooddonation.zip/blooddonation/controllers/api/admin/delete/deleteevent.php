<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit();
}

$host = "localhost";
$username = "root";
$password = "";
$dbname = "blooddonation";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

$eventId = isset($_GET['id']) ? intval($_GET['id']) : null;

if (!$eventId) {
    http_response_code(400);
    echo json_encode(["error" => "Event ID is required."]);
    exit();
}

$query = "DELETE FROM event WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $eventId);

if ($stmt->execute()) {
    echo json_encode(["message" => "Event deleted successfully."]);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to delete the event."]);
}

$stmt->close();
$conn->close();
?>
