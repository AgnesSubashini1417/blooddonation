<?php
// Enable CORS for local development
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$dbname = "blooddonation";

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Fetch all blood banks
$query = "SELECT bloodbank AS name, Location AS location, Contact AS contact FROM bloodbank";
$result = $conn->query($query);

if ($result) {
    $bloodBanks = $result->fetch_all(MYSQLI_ASSOC); // Fetch all results as associative array
    echo json_encode($bloodBanks);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to fetch blood banks."]);
}

$conn->close();
?>
