<?php
// Enable CORS for local development
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$dbname = "blooddonation";

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Fetch all donors
$query = "SELECT Fullname, Email, Bloodtype, Location FROM donorregister";
$result = $conn->query($query);

if ($result) {
    $donors = [];
    while ($row = $result->fetch_assoc()) {
        $donors[] = $row;
    }
    echo json_encode($donors);
} else {
    http_response_code(500);
    echo json_encode(["error" => "Failed to fetch donors."]);
}

$conn->close();
?>
