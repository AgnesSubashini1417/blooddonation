<?php
// Enable CORS for local development
header("Access-Control-Allow-Origin: http://localhost:5173"); // Allow requests from the frontend
header("Access-Control-Allow-Methods: POST, OPTIONS"); // Allow POST and preflight OPTIONS
header("Access-Control-Allow-Headers: Content-Type, Authorization"); // Allow necessary headers
header("Access-Control-Allow-Credentials: true"); // Allow credentials if needed

// Handle OPTIONS preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200); // Respond with 200 OK for preflight
    exit();
}

// Database configuration
$host = "localhost"; // Database host (usually localhost)
$username = "root";  // Database username
$password = "";      // Database password (leave empty for XAMPP default)
$dbname = "blooddonation"; // Name of your database

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
    exit();
}

// Read JSON input from the request body
$data = json_decode(file_get_contents("php://input"), true);

// Validate input data
if (isset($data['Fullname'], $data['Email'], $data['Password'], $data['Role'])) {
    $Fullname = $data['Fullname'];
    $Email = $data['Email'];
    $Password = $data['Password'];
    $Role = $data['Role'];

    try {
        // Prepare the SQL query
        $query = "INSERT INTO signup (Fullname, Email, Password, Role) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);

        // Bind parameters
        $stmt->bind_param("ssss", $Fullname, $Email, $Password, $Role);

        // Execute the query
        if ($stmt->execute()) {
            echo json_encode(["message" => "User created successfully"]);
        } else {
            http_response_code(500);
            echo json_encode(["error" => "Failed to create user: " . $stmt->error]);
        }

        // Close the statement
        $stmt->close();
    } catch (Exception $e) {
        // Return an error response in case of exceptions
        http_response_code(500);
        echo json_encode(["error" => "Server error: " . $e->getMessage()]);
    }
} else {
    // Return an error if required fields are missing
    http_response_code(400);
    echo json_encode(["error" => "Invalid input data"]);
}

// Close the database connection
$conn->close();
?>
